library(tidyverse)
# 1. Crear un nuevo proyecto denominado practica 4.

# 2. Mediante la libreria readr, o mediante los menus de RStudio, leer los datasets sleep.csv  y activities.csv
# ambos archivos deben estar previamente en la carpeta del proyecto creado
library(readr)
activities <- read_csv("~/Desktop/R/Práctica 4/activities.csv")
View(activities)

# 3.Comprobar el contenido  con View y contar cuantos NAs hay en la columna GPS del dataset activities
GPSNA<-filter(activities, is.na(GPS)) #305 NAs

# 4. Crear un objeto R denominado act_new que contenga solo las variables 
# siguientes: 1,2,5-6
act_new<-select(activities, 1,2,5,6)

# 5. Renombrar la variable 'Activity type' con el nombre 'tipo' y la variable 'Time zone' como 'ciudad'
# También se podría hacer así: names(act_new)[4]= "Tipo"
act_new<-rename(act_new,"tipo"="Activity type", "ciudad"="Timezone")

# 6. Realizar un recuento de tipo de actividad con summary. Para ello 
# debes transformar previamente la variable tipo a factor con as.factor.
# Crea un grafico de barras con dicha variable par visualizar las frecuencias.
# Haz lo mismo para la variable ciudad
act_new$tipo<-as.factor(act_new$tipo)
summary(act_new$tipo)
plot(act_new$tipo, main="activities")
act_new$ciudad<-as.factor(act_new$ciudad)
summary(act_new$ciudad)
plot(act_new$ciudad, main="cities")

#7. Filtrar los registros de act_new que correspondan con ciudad Amsterdam en otro objeto
# y lo mismo con Madrid. Con esos nuevos objetos determina los deportes que 
# no se practican en Amsterdam y s? en Madrid y viceversa.(Hay que comentarlo) Genera graficos para visualizar los resultados
amsterdam<-filter(act_new, ciudad=="Europe/Amsterdam")
madrid<-filter(act_new, ciudad == "Europe/Madrid")
amsterdam$tipo<-as.factor(amsterdam$tipo)
summary(amsterdam$tipo)
plot(amsterdam$tipo, main="deportes Amsterdam")
madrid$tipo<-as.factor(madrid$tipo)
summary(madrid$tipo)
plot(madrid$tipo, main="deportes Madrid")
#como podemos ver en "summary(amsterdam$tipo)" y en "summary(madrid$tipo)", en Amsterdam no se practican los deportes Hiking, otros deportes, ski, natacion ni tenis pero en Madrid si se practican
#Dancing no se practica en Madrid pero si en Amsterdam

#Vamos a comprobarlo:
dep_mad<-madrid$tipo #nos quedamos solo con los deportes 
dep_ams<-amsterdam$tipo
n<-length(dep_mad) #esto es para ver la totalidad de elementos, y comprobamos que estan repetidos
m<-length(dep_ams)
mad<- unique(dep_mad) #con esta instruccion nos quedamos solo con los deportes que se practican en madrid, sin sus repeticiones
ams<-unique(dep_ams) #y lo mismo con los deportes que se practican en amsterdam
imprimedepmadams<- function(mad,ams) { #ahora hacemos un bucle que busque en la segunda lista si encuentra el deporte que aparece en la primera y que imprima los que no se encuentran
  for (i in 1:length(mad)) {
    enc<-FALSE
    for (j in 1:length(ams)) {
      if (ams[j] == mad [i])
      {enc<-TRUE}
    } 
    if (!enc)print(mad[i])
  }
}
imprimedepmadams(mad,ams) #aqui podemos ver los deportes que se practican en madrid y no se practican en amsterdam 
imprimedepmadams(ams,mad) #aqui podemos ver los deportes que se practican en amsterdam pero no se practican en madrid


#8. Encontrar las fechas en las que se ha practicado bicicleta o pilates en Amsterdam en el a?o 2019.
#·(filter oposicion de cosas y si no sale quitar lo del año 2019, porque el año viene en formato hora y hay que transformar)
bicipilatesamsterdam<-filter(amsterdam, tipo=="Cycling"|tipo=="Pilates")
view(bicipilatesamsterdam)

#9. Crear una nueva variable dif con los minutos de realizaci?n de cada actividad en Amsterdam
# y realizar una representaci?n gr?fica de los resultados con plot y determinar que deporte o deportes
# se han practicado durante dos horas o mas (filter)
amsterdamdeportes<-select(amsterdam, 1,2,4) #seleccionamos las columnas que nos interesan
actnewminutos<-mutate(amsterdamdeportes, dif=a-de) #creamos la variable dif que incluye los minutos de realizacion de la actividad
actnew2<-actnewminutos %>%
  group_by(tipo)%>%
  summarize(totalminutos=sum(dif)) #creamos una nueva base de datos llmada actnew2 que incluye el tipo de actividad y el total de minutos que se han dedicado para esa actividad 
filter(actnew2, totalminutos>=120) #filtramos para que nos muestre los deportes que se han practicado 2 horas o mas
ggplot(actnew2, aes(x= tipo, y = totalminutos))+
  geom_bar(stat = "identity") + 
  xlab("Deporte") +
  ylab("Minutos") #y lo representamos

#10. Guardar el nuevo dataset en un archivo llamado  "act_new.csv"
write.csv(actnew2, file = "act_new.csv")

#-------------------------------
#-----SEGUNDA PARTE-------------
# 11. Cargar el dataset sleep en un objeto llamado sleep
library(readr)
sleep <- read_csv("~/Desktop/R/Práctica 4/sleep.csv")
View(sleep)

#12. crear un nuevo data set llamado sleep_new que contenga solo las variables
#que contengan informaci?n, que no sean todo cero.
sleep_new<-select(sleep,1,2,3,4,6,7,8,9)

#13. Renombrar las variables de sleep_new a nombres cortos:
sleep_new<-rename(sleep_new,"ligero"="ligero (s)", "profundo"="profundo (s)", "despierto"="despierto (s)", "tparadormir"="Duration to sleep (s)", "tparadespertar"="Duration to wake up (s)" )

#14. Eliminar todas las filas que contengan alg?n NA (aunq contengan solo 1)
summarise_all(sleep_new, funs(sum(is.na(.))))
sleep_new <- na.omit(sleep_new)
summarise_all(sleep_new, funs(sum(is.na(.))))

# 15. Calcular cuanto tiempo en total se ha dormido cada noche: ligero+profundo 
sleep_new<-mutate(sleep_new, sueñototal=ligero+profundo)

# 16. Visualizacion de la relacion ligero-profundo-total (ggplot2 ligero profundo, ligero total, profundo total)
ggplot(data=sleep_new) + geom_point(mapping = aes(x= ligero, y = profundo))
ggplot(data=sleep_new) + geom_point(mapping = aes(x= sueñototal, y = ligero))
ggplot(data=sleep_new) + geom_point(mapping = aes(x= sueñototal, y = profundo))


# A la vista de los resultados, que tipo de sue?o es mas relevante?
#si calculamos la media de sueño ligero y sueño profundo, la media mas alta es la mas relevante 
medialigero<-mean(sleep_new$ligero)
medialigero
mediaprofundo<-mean(sleep_new$profundo)
mediaprofundo
#como podemos observar, el sueño profundo es mas relevante en este caso, ya que su media es mas grande


# 17. Realizar un analisis de diferencias entre los dos tipos de sue?o e interpretar los resultados
# usar la funci?n ICalpha o el 'One sample t-test' de TeachingDemos: t.test()
# ejecutando estas instrucciones nos va a dar intervalos de confianza para las medias, si 0 pertenece al intervalo significa que no hay diferencia significativa
#HO:no existen diferencias significativas
#H1: existen diferencias significativas
ligero1<-sleep_new$ligero
profundo1<-sleep_new$profundo
ICalpha<-function(profundo1, ligero1, alfa=0.05)
{
  n<-length(profundo1)
  diferencias<- profundo1 - ligero1
  mediad<-mean(diferencias)
  s<-sqrt(var(diferencias))
  valort<-qt(alfa/2,n-1,lower.tail = F)
  valor<-valort*s/sqrt(n)
  cotaInf<-mediad-valor
  cotaSup<-mediad+valor
  df<-data.frame(cotaInf, cotaSup)
  return(df)
}
plot(profundo1, ligero1)
IC<-ICalpha(profundo1, ligero1, 0.05)
print('Intervalo al 95% de confianza')
IC

# cotaInf = 491.9643, cotaSup = 1731.623, como 0 no pertenece al intervalo de confianza, hay diferencia significativa.
#con un nivel de confianza del 95% y de significatividad del 5%, se rechaza la hipotesis nula ya que existen diferencias significativas

#18. Crear una nueva variable 'ciudad' en sleep_new con la informacion de act_new. (sleep no tiene la variable ciudad, asi que solo la creamos y luego ya meteremos el contenido)
#cojo de sleep el primer registroy ver si en activities está esa fecha y busco en activities en que ciudad estoy y la copio)
sleep_new$ciudad<-NA #creamos una columna en sleep_new que se llama ciudad 
activities$a<- as.Date(activities$a) #convertimos a fecha los datos de "a" en cada caso para deshacernos de las horas minutos y segundos
sleep_new$a <- as.Date(sleep_new$a)
for(i in 1:length(sleep_new$a)){  #y hacemos el bucle que nos recorra las fechas de actividades para que cuando coincida con la fecha de sleep, copie el dato de ciudad y lo incorpore en la columna de ciudad de sleep 
  for (j in 1:length(activities$a)) {
    if (sleep_new$a[i] == activities$a [j]){
      sleep_new$ciudad[i]<-activities$Timezone [j]
    } 
  }}
#he cogido el dataframe de activities y no el de act_new ya que en el segundo habia convertido las ciudades en factor


#19. Representar la relaci?n totalsleep y profundo usando como facetas el factor ciudad
ggplot(data=sleep_new) + geom_point(mapping = aes(x= sueñototal, y = profundo, color = ciudad))

#20. Guardar el dataset sleep_new en un archivo "sleep_new.csv"
write.csv(sleep_new, file= "sleep_new.csv")

#21. Guardar el proyecto completo. Subir la carpeta del proyecto al campus.
